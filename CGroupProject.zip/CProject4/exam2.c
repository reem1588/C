#include<stdio.h>


int main()
{
	int num = 0;

	while (num < 5)
	{
		printf("hello world! %d\n", num);
		num = num + 1;
	}



	return 0;
}