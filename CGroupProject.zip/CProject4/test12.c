#include<stdio.h>


int main()
{
	int i ,j; 

	for (i = 1; i <= 9; i++)
	{
		for (j = 2; j <= 8; j =j+ 3)
		{
			printf("%d8%d=%2d", j, i, j * i);
		}
		printf("\n");
		
		
	}
	

	return 0;
}