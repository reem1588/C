//�ٽ� ����
#include<stdio.h>

int main()
{
	int hap;
	int hap2;

	hap = 10 + 20;
	printf("%d\n", hap);
	hap2 = hap;
	printf("%d", hap2);

	return 0;
}