#include<stdio.h>

int main()
{
	printf("%d*%d=%d\n", 4, 5, 4 * 5);
	printf("%d*%d=%d", 7, 9, 7*9);
	
	return 0;

}