#include<stdio.h>

int main()
{
	int ary[5] = { 10,20,30,40,50 };
	int* ap = ary;
	int i;

	for (i = 0; i < 5; i++)
	{
		// printf("%5d", *(ap+i)); �̰͵���
		printf("%5d", *ap);
		ap++;
	}





	return 0;
}

