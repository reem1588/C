#include<stdio.h>

typedef struct person
{
	char name[20];
	char phoneNumber[20];
	int age;
}Person;

void ShowPersonInfo(Person man)
{
	printf("name : %s\n", man.name);
	printf("phone : %s\n", man.phoneNumber);
	printf("age : %d\n", man.age);
}

Person ReadPersonInfo()
{
	Person man;
	printf("name?");
	scanf_s("%s",man.name,20); // name�� �迭�̱� ������ &�Ⱥ���
	printf("phone?");
	scanf_s("%s",man.phoneNumber,20);
	printf("age?");
	scanf_s("%d", &man.age);

	return man;

}
int main()
{
	Person man = ReadPersonInfo();
	ShowPersonInfo(man);
	

	return 0;
}