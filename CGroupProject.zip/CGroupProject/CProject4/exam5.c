#include<stdio.h>


int main()
{
	int x = 0;
	int y = 0;

	while (y < 5)
	{
		x = 0;
		while (x < 4) // x�� �� 0 1 2 3 4���̴� 
		{
			printf("*\t");
			x = x + 1;
		}
	putchar('\n');
	y = y + 1;

	}

	return 0;
}