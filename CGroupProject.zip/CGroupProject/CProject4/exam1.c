#include<stdio.h>


int main()
{
	int nInput = 0;
	// while �ݺ���(������ �����ϴ� ����)
	printf("%dth printf()\n", 5);
	printf("%dth printf()\n", 4);
	printf("%dth printf()\n", 3);
	printf("%dth printf()\n", 2);
	printf("%dth printf()\n", 1);

	scanf_s("%d", &nInput);

	while (nInput > 0)
	{
		printf("%dth printf()\n", nInput);
		//nInput--;
		nInput = nInput - 1;
	}
	


	return 0;
}