#include <stdio.h>

int main()
{
	printf("welcome to C world!!");

	return 0;
}