// my age : 20
// 100 is my point
// good
// morning
// everybody

#include<stdio.h>

int main()
{
	printf("my age : %d\n", 20);
	printf("%d is my point\n", 100);
	printf("Good\nmorning\neverybody");

	return 0;

}