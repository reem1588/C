#include<stdio.h>

int main()
{
	int nData = 10;
	int nNewData = 20;
	int nResult = 10;

	printf("%d\n", nData == nResult);
	printf("%d\n", nData != nResult);
	printf("%d\n", nData > nResult);
	printf("%d\n", nData < nResult);
	printf("%d\n", nData >= nResult);
	printf("%d\n", nData <= nResult);



	return 0;
}