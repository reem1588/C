#include<stdio.h>

int main()
{
	int nInput = 0;

	scanf_s("%d", &nInput);
	if (nInput >= 10) 
	{
		puts("10�̻�");
	}
	else
	{
		puts("10�̸�");
	}
	



	return 0;
}