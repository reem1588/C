#include<stdio.h>

int main()
{
	int result;
	result = 10 / 4;
	
	printf("%d\n", result);
	printf("%d\n", 10 / 4);
	//printf("%lf\n", 10 / 4);
	printf("%lf\n", 10 / 4.0);






	return 0;
}